from datetime import datetime
from pathlib import Path
from fpdf import FPDF
from app.config import EXPORTS_DIR, BASE_DIR


def _local_image_path(url_path: str) -> Path:
    relative = url_path.removeprefix("/static/")
    return BASE_DIR / "static" / relative


def save_pdf(layout: list[dict]) -> str:
    filename = f"comiccraft_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    output = EXPORTS_DIR / filename
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel['panel_number']}: {panel['title']}")
        image_file = _local_image_path(panel["image_path"])
        if image_file.exists():
            pdf.image(str(image_file), x=20, y=35, w=170, h=125)
            pdf.set_y(165)
        else:
            pdf.set_y(45)
        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, panel["scene_description"])
        pdf.ln(3)
        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Caption")
        pdf.set_font("Helvetica", size=10)
        pdf.multi_cell(0, 6, panel["caption"])
        pdf.ln(2)
        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Narration")
        pdf.set_font("Helvetica", size=10)
        pdf.multi_cell(0, 6, panel["narration"])
        if panel.get("dialogue"):
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 6, "Dialogue")
            pdf.set_font("Helvetica", size=10)
            pdf.multi_cell(0, 6, panel["dialogue"])

    pdf.output(str(output))
    return f"/static/exports/{filename}"
