import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from huggingface_hub import InferenceClient
from app.config import settings, PANELS_DIR


def _safe_name(text: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_-]+", "_", text).strip("_")
    return cleaned[:60] or "panel"


def _demo_image(prompt: str, panel_number: int, title: str, output: Path) -> None:
    image = Image.new("RGB", (settings.image_width, settings.image_height), "#fff4dc")
    draw = ImageDraw.Draw(image)
    draw.rectangle((25, 25, settings.image_width - 25, settings.image_height - 25), outline="#171717", width=8)
    draw.text((55, 55), f"COMICCRAFT • PANEL {panel_number}", fill="#171717")
    draw.text((55, 125), title[:45], fill="#171717")
    draw.text((55, 220), "DEMO IMAGE", fill="#8b2f2f")
    draw.multiline_text((55, 300), prompt[:500], fill="#333333", spacing=12)
    image.save(output, "PNG")


def generate_image(prompt: str, panel_number: int, title: str = "Panel") -> str:
    filename = f"panel_{panel_number}_{_safe_name(title)}.png"
    output = PANELS_DIR / filename

    if settings.demo_mode or not settings.hf_token:
        _demo_image(prompt, panel_number, title, output)
        return f"/static/panels/{filename}"

    client = InferenceClient(api_key=settings.hf_token, provider=settings.hf_provider)
    image = client.text_to_image(
        prompt=prompt,
        model=settings.hf_image_model,
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
        negative_prompt="blurry, distorted, extra fingers, watermark, text, logo",
    )
    image.save(output)
    return f"/static/panels/{filename}"
