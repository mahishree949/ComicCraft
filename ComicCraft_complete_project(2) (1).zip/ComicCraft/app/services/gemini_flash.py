import json
from typing import List
from google import genai
from google.genai import types
from app.config import settings
from app.schemas import ComicOutline, PanelOutline


def _demo_outline(story_prompt: str, character_name: str, setting: str, tone: str, art_style: str) -> List[dict]:
    beats = [
        ("A New Beginning", f"{character_name} arrives in {setting}, ready to discover something unexpected."),
        ("The Mystery", f"A strange clue appears, drawing {character_name} deeper into {setting}."),
        ("The Challenge", f"{character_name} faces a difficult obstacle but finds a clever way forward."),
        ("The Turning Point", f"A surprising discovery changes what {character_name} thought was possible."),
        ("A Bright Ending", f"{character_name} completes the journey and leaves {setting} with a new lesson."),
    ]
    return [
        {
            "panel_number": i + 1,
            "title": title,
            "scene_description": desc,
            "image_prompt": (
                f"{art_style} comic illustration, {setting}, main character {character_name}, "
                f"{desc} Story idea: {story_prompt}. Tone: {tone}. Consistent character design, "
                "cinematic composition, expressive faces, clean details, no text or speech bubbles."
            ),
        }
        for i, (title, desc) in enumerate(beats)
    ]


def generate_outline(story_prompt: str, character_name: str, setting: str, tone: str, art_style: str) -> List[dict]:
    if settings.demo_mode or not settings.gemini_api_key:
        return _demo_outline(story_prompt, character_name, setting, tone, art_style)

    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f"""
Create exactly {settings.panel_count} connected comic panels.
Story idea: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Return only structured data matching the supplied schema. Each panel must have:
- panel_number
- title
- scene_description
- image_prompt
Keep the character, setting, and visual continuity consistent across panels.
Do not put dialogue into image_prompt; describe only what should be visible.
"""
    response = client.models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicOutline,
            temperature=0.9,
            max_output_tokens=3000,
        ),
    )
    if getattr(response, "parsed", None):
        return [panel.model_dump() for panel in response.parsed.panels]
    data = json.loads(response.text)
    return ComicOutline.model_validate(data).model_dump()["panels"]
