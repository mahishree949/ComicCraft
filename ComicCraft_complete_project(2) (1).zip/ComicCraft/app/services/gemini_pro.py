import json
from typing import List, Dict
from google import genai
from google.genai import types
from app.config import settings
from app.schemas import ComicStory


def _demo_story(outline: List[dict], character_name: str, tone: str) -> List[dict]:
    return [
        {
            "panel_number": p["panel_number"],
            "caption": f"{p['title']} — the story moves forward.",
            "narration": p["scene_description"] + f" {character_name} keeps going despite the uncertainty.",
            "dialogue": f"{character_name}: We can do this!",
        }
        for p in outline
    ]


def generate_story(outline: List[dict], character_name: str, tone: str) -> List[dict]:
    if settings.demo_mode or not settings.gemini_api_key:
        return _demo_story(outline, character_name, tone)

    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f"""
Expand this {tone} comic outline into exactly one story object for every panel.
Main character: {character_name}
Outline JSON:
{json.dumps(outline, ensure_ascii=False)}

For every panel provide panel_number, caption, narration, and dialogue.
Keep the story coherent and concise. Dialogue should be suitable for a general audience.
Return only structured data matching the supplied schema.
"""
    response = client.models.generate_content(
        model=settings.gemini_story_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicStory,
            temperature=0.85,
            max_output_tokens=3500,
        ),
    )
    if getattr(response, "parsed", None):
        return [panel.model_dump() for panel in response.parsed.panels]
    data = json.loads(response.text)
    return ComicStory.model_validate(data).model_dump()["panels"]
