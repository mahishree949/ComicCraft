from typing import List, Dict


def build_comic_layout(outline: List[dict], story: List[dict], image_paths: List[str]) -> List[dict]:
    story_by_panel = {item["panel_number"]: item for item in story}
    layout = []
    for index, panel in enumerate(outline):
        narrative = story_by_panel.get(panel["panel_number"], {})
        layout.append({
            "panel_number": panel["panel_number"],
            "title": panel["title"],
            "image_path": image_paths[index],
            "scene_description": panel["scene_description"],
            "image_prompt": panel["image_prompt"],
            "caption": narrative.get("caption", ""),
            "narration": narrative.get("narration", ""),
            "dialogue": narrative.get("dialogue", ""),
        })
    return layout
