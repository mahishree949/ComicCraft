from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path

from app.config import TEMPLATES_DIR, BASE_DIR, settings
from app.schemas import PromptRequest
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout
from app.services.exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


def generate_comic(data: PromptRequest) -> tuple[list[dict], str]:
    outline = generate_outline(
        data.story_prompt, data.character_name, data.setting, data.tone, data.art_style
    )
    story = generate_story(outline, data.character_name, data.tone)
    image_paths = [
        generate_image(panel["image_prompt"], panel["panel_number"], panel["title"])
        for panel in outline
    ]
    layout = build_comic_layout(outline, story, image_paths)
    pdf_path = save_pdf(layout)
    return layout, pdf_path


@router.get("/")
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"settings": settings})


@router.post("/generate")
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(
            story_prompt=story_prompt.strip(), character_name=character_name.strip(),
            setting=setting.strip(), tone=tone.strip(), art_style=art_style.strip()
        )
        layout, pdf_path = generate_comic(data)
        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={"layout": layout, "pdf_path": pdf_path, "demo_mode": settings.demo_mode},
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="error.html",
            context={"error": str(exc)},
            status_code=500,
        )


@router.post("/generate-comic/json")
async def generate_json(data: PromptRequest):
    try:
        layout, pdf_path = generate_comic(data)
        return {"success": True, "layout": layout, "pdf_path": pdf_path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/test-image")
async def test_image(prompt: str = Form(...)):
    try:
        path = generate_image(prompt, 0, "image_test")
        return {"success": True, "image_path": path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/download/{filename}")
async def download_pdf(filename: str):
    safe_name = Path(filename).name
    file_path = BASE_DIR / "static" / "exports" / safe_name
    if not file_path.is_file() or file_path.suffix.lower() != ".pdf":
        raise HTTPException(status_code=404, detail="PDF not found")
    return FileResponse(file_path, media_type="application/pdf", filename=safe_name)


@router.get("/export-success")
async def export_success(request: Request):
    return templates.TemplateResponse(request=request, name="export_success.html", context={})
