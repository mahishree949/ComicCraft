from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.config import STATIC_DIR, settings
from app.routes import router

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description="AI comic story creator using Gemini and Hugging Face image generation.",
)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.include_router(router)

@app.get("/health")
async def health():
    return {"status": "ok", "app": settings.app_name, "demo_mode": settings.demo_mode}
