# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI + Jinja2 web application that turns a story prompt into a five-panel comic workflow: structured outline → narration/dialogue → illustrations → preview → PDF export.

## Architecture

- `app/main.py` — FastAPI application and static files
- `app/routes.py` — browser and JSON API routes
- `app/schemas.py` — Pydantic request/response structures
- `app/services/gemini_flash.py` — panel outline generation
- `app/services/gemini_pro.py` — story/narration generation
- `app/services/image_generator.py` — Hugging Face image generation
- `app/services/layout_builder.py` — combines panels
- `app/services/exporters.py` — PDF creation
- `templates/` — Jinja2 pages
- `static/` — CSS, JavaScript, generated panels and PDFs

## Important implementation note

The original documentation specifies `google-generativeai` and Gemini 1.5 model names. This implementation uses Google's current `google-genai` SDK and configurable current Gemini model names, while preserving the documented architecture and function names. The image layer uses Hugging Face `InferenceClient` so image generation can be remote rather than requiring a local GPU.

## Quick start

### Windows PowerShell

```powershell
cd ComicCraft
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

API docs: http://127.0.0.1:8000/docs
Health check: http://127.0.0.1:8000/health

### macOS/Linux

```bash
cd ComicCraft
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

## Demo mode

`DEMO_MODE=true` requires no API keys. It exercises the complete FastAPI → Jinja2 → image placeholder → layout → PDF pipeline.

For real AI:
1. Put your Gemini API key in `.env` as `GEMINI_API_KEY=...`.
2. Put a Hugging Face token with inference permission in `.env` as `HF_TOKEN=...`.
3. Set `DEMO_MODE=false`.
4. Restart Uvicorn.

## API example

POST JSON to `/generate-comic/json`:

```json
{
  "story_prompt": "A brave fox exploring an enchanted forest",
  "character_name": "Fia",
  "setting": "enchanted forest",
  "tone": "funny",
  "art_style": "comic book"
}
```

## Testing

With the server running:

```bash
curl http://127.0.0.1:8000/health
```

Then use `/docs` to test `/generate-comic/json` and `/test-image` interactively.

Run local tests:

```bash
pytest -q
```
