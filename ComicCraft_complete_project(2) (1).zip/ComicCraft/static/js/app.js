document.addEventListener('submit', function (event) {
  const form = event.target;
  if (form.matches('form[action="/generate"]')) {
    const button = form.querySelector('button[type="submit"]');
    if (button) { button.disabled = true; button.textContent = 'Generating comic…'; }
  }
});
